LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY WCXRKCZ IS
PORT(
    ADDR: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    DOUT: OUT STD_LOGIC_VECTOR(3 DOWNTO 0)
);
END WCXRKCZ;

ARCHITECTURE A OF WCXRKCZ IS
BEGIN
    PROCESS
    BEGIN
        CASE ADDR IS  
            WHEN "0001" => DOUT <= "0010";  
            WHEN "0010" => DOUT <= "0011";
            WHEN "0011" => DOUT <= "0100";
            WHEN "0100" => DOUT <= "0101";
            WHEN "0101" => DOUT <= "0111";
            WHEN "0110" => DOUT <= "1001";
            WHEN "0111" => DOUT <= "1010";
            WHEN "1000" => DOUT <= "1011";
            WHEN "1001" => DOUT <= "1100";
            WHEN "1010" => DOUT <= "1101";
            WHEN OTHERS => DOUT <= "0000"; 
        END CASE;
    END PROCESS;
END A;


