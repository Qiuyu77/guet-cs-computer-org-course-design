LIBRARY IEEE;                                             
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY ALU IS
PORT(
     X: IN STD_LOGIC_VECTOR(7 DOWNTO 0);
     Y: IN STD_LOGIC_VECTOR(7 DOWNTO 0);
     S2,S1,S0: IN STD_LOGIC;
     ALUOUT: OUT STD_LOGIC_VECTOR(7 DOWNTO 0) ;
     SF,OF_1: OUT STD_LOGIC
    );
END ALU;

ARCHITECTURE A OF ALU IS
SIGNAL AA,BB,TEMP:STD_LOGIC_VECTOR(8 DOWNTO 0);
SIGNAL TEMP1:STD_LOGIC_VECTOR(7 DOWNTO 0);
BEGIN 
    PROCESS
    BEGIN 
        IF(S2='0' AND S1='0' AND S0='0') THEN
            AA<='0'&X;
            BB<='0'&Y;
            TEMP<=AA+BB;
            ALUOUT<=TEMP(7 DOWNTO 0);
            SF <= TEMP(7);
            OF_1 <= (X(7) AND Y(7) AND NOT TEMP(7)) OR (NOT X(7) AND NOT Y(7) AND TEMP(7));

        ELSIF(S2='0' AND S1='0' AND S0='1') THEN
            AA<='0'&X;
            BB<='0'&Y;
            TEMP<=AA-BB;
            ALUOUT<=TEMP(7 DOWNTO 0);
            SF <= TEMP(7);
            OF_1 <= (X(7) AND NOT Y(7) AND NOT TEMP(7)) OR (NOT X(7) AND Y(7) AND TEMP(7));

        ELSIF(S2='0' AND S1='1' AND S0='0') THEN
            TEMP <= "000000000" - ('0'&Y);
            ALUOUT<=TEMP(7 DOWNTO 0);
            SF <= TEMP(7);
            OF_1 <= (Y(7) AND TEMP(7));

        ELSIF(S2='0' AND S1='1' AND S0='1') THEN
            AA<='0'&Y;
            TEMP<=AA-1;
            ALUOUT<=TEMP(7 DOWNTO 0);
            SF <= TEMP(7);
            OF_1 <= (NOT Y(7) AND TEMP(7));

        ELSIF(S2='1' AND S1='0' AND S0='0') THEN
            ALUOUT <= X AND Y;
            SF <= (X(7) AND Y(7));
            OF_1 <= '0';

        ELSIF(S2='1' AND S1='0' AND S0='1') THEN
            ALUOUT <= X OR Y;
            SF <= (X(7) OR Y(7));
            OF_1 <= '0';

        ELSIF(S2='1' AND S1='1' AND S0='0') THEN
            ALUOUT<=Y;
            SF <= Y(7);
            OF_1 <= '0';

        ELSE
            ALUOUT<="00000000" ;
            SF<='0';
            OF_1<='0';
        END IF;
    END PROCESS;
END A;
