LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY MUX4_1_W IS
PORT(
    WO, WI: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
    X1, X0: IN STD_LOGIC;
    W_OUT: OUT STD_LOGIC_VECTOR(3 DOWNTO 0)
);
END MUX4_1_W;

ARCHITECTURE A OF MUX4_1_W IS
BEGIN
    PROCESS(X1, X0, WO, WI)
    BEGIN
        IF(X1='0' AND X0='0') THEN
            W_OUT <= WO;
        ELSIF(X1='0' AND X0='1') THEN
            W_OUT <= WI;
        ELSIF(X1='1' AND X0='0') THEN
            W_OUT <= WO;
        ELSE
            W_OUT <= "0000";
        END IF;
    END PROCESS;
END A;
