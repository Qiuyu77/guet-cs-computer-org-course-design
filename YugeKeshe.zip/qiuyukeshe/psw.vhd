LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY PSW IS
PORT(
    PSWin: IN STD_LOGIC;
    SF, OF_1, CLK: IN STD_LOGIC;
    S, O: OUT STD_LOGIC
);
END PSW;

ARCHITECTURE A OF PSW IS
BEGIN
    PROCESS(CLK, PSWin)  
    BEGIN
        IF rising_edge(CLK) THEN 
            IF PSWin = '1' THEN 
                S <= SF;
                O <= OF_1;
            END IF;
        END IF;
    END PROCESS;
END A;

