LIBRARY IEEE;                                                      
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY MUX3_1 IS
PORT(
	INBUS,RAM_OUT,FEN2_OUT:IN STD_LOGIC_VECTOR(7 DOWNTO 0);
	SWout,RAMout:IN STD_LOGIC;
	DBUS:OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
);
END MUX3_1;
ARCHITECTURE A OF MUX3_1 IS
BEGIN
        PROCESS
        BEGIN 
         IF(SWout='1') THEN     			
                 DBUS<=INBUS;
	     ELSIF(RAMout='1')THEN 
	             DBUS<=RAM_OUT;			
	     ELSE
	             DBUS<=FEN2_OUT;
	     END IF;
        END PROCESS;
END A;

