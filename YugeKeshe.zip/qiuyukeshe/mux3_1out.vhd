LIBRARY IEEE;                                                      
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY MUX3_1OUT IS
PORT(
	ALU_OUT,R_OUT,IR_OUT:IN STD_LOGIC_VECTOR(7 DOWNTO 0);
	ALUout,Rout,IR_A_OUT:IN STD_LOGIC;
	DBUS:OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
);
END MUX3_1OUT;
ARCHITECTURE A OF MUX3_1OUT IS
BEGIN
        PROCESS(ALUout,Rout,IR_A_OUT)
        BEGIN 
			IF(ALUout='1') THEN     			
                 DBUS<=ALU_OUT;
	     	ELSIF(Rout='1')THEN 
	             DBUS<=R_OUT;			
	     	ELSIF(IR_A_OUT='1')THEN
	             DBUS<=IR_OUT;
	     END IF;
        END PROCESS;
END A;
