LIBRARY IEEE;                                       
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY R3 IS
PORT(
     D: IN STD_LOGIC_VECTOR(7 DOWNTO 0);
     CLK,EN: IN STD_LOGIC;
     Q: OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
    );
END R3;
ARCHITECTURE A OF R3 IS
SIGNAL Q1:STD_LOGIC_VECTOR(7 DOWNTO 0);
BEGIN 
     PROCESS(CLK,EN)
     BEGIN
          IF (CLK'EVENT AND CLK='0') THEN
              IF EN='1' THEN
                  Q1<=D;
              END IF;
          END IF;
     END PROCESS;
     Q<=Q1;
END A;

